import os
import re

REPO_DIR = "murphys-lore-"
CSS_FILE_1 = os.path.join(REPO_DIR, "styles.css")
CSS_FILE_2_HTML = os.path.join(REPO_DIR, "murphys-lore-final-updated.html")
JS_FILE_1 = os.path.join(REPO_DIR, "script.js")
JS_FILE_2_HTML = os.path.join(REPO_DIR, "murphys-lore-final-updated.html")
NEW_CSS_FILE = os.path.join(REPO_DIR, "campaign-styles.css")
NEW_JS_FILE = os.path.join(REPO_DIR, "campaign-script.js")
NEW_HTML_FILE = os.path.join(REPO_DIR, "index.html") # Overwrite the old index.html

# --- 1. Consolidate CSS ---
def consolidate_css():
    print("Consolidating CSS...")
    with open(CSS_FILE_1, 'r') as f:
        css_content_1 = f.read()

    with open(CSS_FILE_2_HTML, 'r') as f:
        html_content_2 = f.read()

    # Extract embedded CSS from the second HTML file
    css_match = re.search(r'<style>\s*(.*?)\s*</style>', html_content_2, re.DOTALL)
    css_content_2 = css_match.group(1).strip() if css_match else ""

    # Combine, adding a separator comment
    combined_css = f"""
/* --- styles.css (Original Landing Page Styles) --- */
{css_content_1}

/* --- murphys-lore-final-updated.html (Campaign/Game Styles) --- */
{css_content_2}
"""
    with open(NEW_CSS_FILE, 'w') as f:
        f.write(combined_css.strip())
    print(f"CSS consolidated to {NEW_CSS_FILE}")

# --- 2. Consolidate JavaScript ---
def consolidate_js():
    print("Consolidating JavaScript...")
    with open(JS_FILE_1, 'r') as f:
        js_content_1 = f.read()

    with open(JS_FILE_2_HTML, 'r') as f:
        html_content_2 = f.read()

    # Extract all script content from the second HTML file
    js_matches = re.findall(r'<script>\s*(.*?)\s*</script>', html_content_2, re.DOTALL)
    js_content_2 = "\n\n// --- Embedded Script Content ---\n\n".join(js_matches)

    # Extract the GAME_B64 variable which is truncated in the read output
    # I will assume the GAME_B64 is in the last script block and read the whole file again to be safe
    # Since I cannot read the whole file, I will manually reconstruct the script logic and placeholder the B64 content.
    # I will read the last part of the file again to get the B64 variable.
    # Since I can't read the whole B64 string, I will use a placeholder and ask the user to provide the full string if needed, but for now, I will assume the game is a separate file.
    # The user wants an offline HTML download, so the game must be embedded. I must get the full B64 string.

    # Re-reading the last part of the file to get the B64 variable name and the logic around it.
    # The previous read showed:
    # 1245	        // Base64-encoded game file (UTF-8)
    # 1246	(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)
    # 1247	        function b64ToUtf8(b64) { ... }
    # 1253	        const gameHtml = b64ToUtf8(GAME_B64);

    # I will modify the consolidation script to extract the GAME_B64 variable definition from the HTML.
    # I will use a more robust regex to capture the variable definition.

    game_b64_match = re.search(r'const GAME_B64\s*=\s*[\'"](.*?)[\'"]', html_content_2, re.DOTALL)
    if not game_b64_match:
        # If the regex fails, I will assume the game is in the file and will need to manually extract it.
        # Since I cannot manually extract it due to truncation, I will proceed with the consolidation and leave a placeholder for the B64 string,
        # which will be the only part that needs manual intervention if the full string is not available.
        # I will use a placeholder and a comment to indicate where the full B64 string should go.
        print("WARNING: Could not find full GAME_B64 variable. Using placeholder.")
        game_b64_placeholder = "const GAME_B64 = '...FULL_BASE64_STRING_HERE...';"
    else:
        game_b64_placeholder = game_b64_match.group(0)

    # Clean up the script content from the second HTML to remove the B64 variable and the IIFE wrapper, as we'll merge the functions.
    js_content_2_cleaned = re.sub(r'const GAME_B64\s*=\s*[\'"].*?[\'"];', '', js_content_2, flags=re.DOTALL)
    js_content_2_cleaned = re.sub(r'\(\(\) => {', '', js_content_2_cleaned)
    js_content_2_cleaned = re.sub(r'}\)\(\);', '', js_content_2_cleaned)
    js_content_2_cleaned = js_content_2_cleaned.strip()

    # Combine, ensuring the B64 variable is at the top of the second script block
    combined_js = f"""
// --- script.js (Original Landing Page Scripts) ---
{js_content_1}

// --- murphys-lore-final-updated.html (Campaign/Game Scripts) ---

// ** IMPORTANT: The full Base64 string for the embedded game is truncated in the context. **
// ** The user must ensure this variable contains the complete, correct Base64 string for the game to work offline. **
// ** For now, I will use a placeholder for the variable definition. **
{game_b64_placeholder}

{js_content_2_cleaned}
"""
    # Replace the CDN link for qrcode.min.js with the local file
    combined_js = combined_js.replace("https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js", "./qrcode.min.js")

    with open(NEW_JS_FILE, 'w') as f:
        f.write(combined_js.strip())
    print(f"JavaScript consolidated to {NEW_JS_FILE}")

# --- 3. Consolidate HTML ---
def consolidate_html():
    print("Consolidating HTML...")
    with open(os.path.join(REPO_DIR, "index.html"), 'r') as f:
        html_content_1 = f.read()

    with open(os.path.join(REPO_DIR, "murphys-lore-final-updated.html"), 'r') as f:
        html_content_2 = f.read()

    # Extract the main content from the second HTML file (everything between <body> and the first <script>)
    body_content_match = re.search(r'<body>(.*?)<script', html_content_2, re.DOTALL)
    if not body_content_match:
        print("Error: Could not find body content in murphys-lore-final-updated.html")
        return

    body_content_2 = body_content_match.group(1).strip()

    # The content of index.html ends with:
    # 103	        <!-- Footer -->
    # 104	        <footer class="footer">
    # 105	            <p>Built with 💎 for Murphy</p>
    # 106	            <p class="footer-subtext">Campaign 2025 | No Cap</p>
    # 107	        </footer>
    # 108	    </div>
    # 109	
    # 110	    <!-- Scripts -->
    # 111	    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    # 112	    <script src="script.js"></script>
    # 113	</body>
    # 114	</html>

    # I will replace the content of the main container in index.html with the combined content.
    # The main container in index.html is: <div class="container">...</div>
    # The content of index.html has a hero, features, qr-section, download-section, stats-section, and footer inside the container.
    # The content of murphys-lore-final-updated.html has a hero, mandala-section, comparison, code, promise, cta.

    # I will keep the original index.html structure and append the new sections.
    # I will remove the original footer from index.html and use the one from the new content, or keep the original and append the new sections before it.
    # I will keep the original index.html's hero, features, qr-section, download-section, stats-section, and then insert the new sections.

    # 1. Remove the old script tags and CDN link from index.html
    html_content_1 = re.sub(r'<script src="https://cdn\.jsdelivr\.net/npm/qrcodejs@1\.0\.0/qrcode\.min\.js"></script>', '', html_content_1)
    html_content_1 = re.sub(r'<script src="script\.js"></script>', '', html_content_1)

    # 2. Replace the old CSS link with the new one
    html_content_1 = html_content_1.replace('<link rel="stylesheet" href="styles.css">', '<link rel="stylesheet" href="campaign-styles.css">')

    # 3. Find the closing tag of the main container in index.html
    container_end_tag = '    </div>\n\n    <!-- Scripts -->'
    
    # 4. Insert the new content before the footer of index.html
    # The new content is everything from the second HTML's body, excluding its own hero section, as index.html already has one.
    # The sections in the second HTML are: hero, mandala-section, comparison, code, promise, cta.
    # I will extract the sections *after* the hero from the second HTML.
    
    # Find the end of the hero section in the second HTML
    hero_end_match = re.search(r'</div>\s*<div class="scroll-indicator"', body_content_2, re.DOTALL)
    if hero_end_match:
        # Content to insert starts after the hero section
        content_to_insert = body_content_2[hero_end_match.end():].strip()
        # Remove the scroll indicator and the closing div of the hero section
        content_to_insert = re.sub(r'</div>\s*<div class="scroll-indicator".*?</div>', '', content_to_insert, flags=re.DOTALL).strip()
    else:
        # Fallback: insert all content from the second HTML's body
        content_to_insert = body_content_2

    # Insert the new content before the footer in the original index.html
    # The original index.html has a footer inside the container. I will replace the original footer with the new content and the new footer.
    # Original index.html footer:
    # 103	        <!-- Footer -->
    # 104	        <footer class="footer">
    # 105	            <p>Built with 💎 for Murphy</p>
    # 106	            <p class="footer-subtext">Campaign 2025 | No Cap</p>
    # 107	        </footer>
    # 108	    </div>

    # I will replace the original stats and footer with the new content, and then add the new script tags.
    
    # Find the end of the stats section in index.html (line 102)
    stats_end_index = html_content_1.find('</section>', html_content_1.find('<!-- Stats Section -->')) + len('</section>')
    
    # Find the start of the footer in index.html (line 103)
    footer_start_index = html_content_1.find('<!-- Footer -->')

    # The content to replace is from the end of the stats section to the end of the body
    content_before_scripts = html_content_1[:footer_start_index]
    content_after_scripts = html_content_1[html_content_1.find('<!-- Scripts -->'):]

    # New combined HTML structure
    new_html = f"""
{html_content_1[:html_content_1.find('<link rel="stylesheet" href="styles.css">')]}
    <link rel="stylesheet" href="campaign-styles.css">
</head>
<body>
    <!-- Animated Background -->
{html_content_1[html_content_1.find('<!-- Animated Background -->'):html_content_1.find('<!-- Stats Section -->')]}
        <!-- Stats Section -->
        <section class="stats-section">
            <div class="stat glass-card">
                <div class="stat-value" data-target="100">0</div>
                <div class="stat-label">% Swag</div>
            </div>
            <div class="stat glass-card">
                <div class="stat-value" data-target="2025">0</div>
                <div class="stat-label">Level</div>
            </div>
            <div class="stat glass-card">
                <div class="stat-value" data-target="999">0</div>
                <div class="stat-label">Vibes</div>
            </div>
        </section>

        <!-- INSERTED CAMPAIGN CONTENT START -->
{body_content_2}
        <!-- INSERTED CAMPAIGN CONTENT END -->

    </div>

    <!-- Scripts -->
    <script src="./qrcode.min.js"></script>
    <script src="./campaign-script.js"></script>
</body>
</html>
"""
    # Clean up the inserted content to remove the second hero section, and the second body/html tags
    # The inserted content starts with the hero section from the second HTML, which I want to remove.
    # I will use a placeholder for the hero section in the second HTML and remove it.
    
    # Find the start of the Mandala section in the second HTML's body content
    mandala_start_match = re.search(r'<!-- Mandala Drawing Section -->', body_content_2, re.DOTALL)
    if mandala_start_match:
        content_to_insert = body_content_2[mandala_start_match.start():].strip()
    else:
        content_to_insert = body_content_2

    # Re-assemble the HTML
    final_html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Murphy's Lore - The Ultimate Captain Campaign">
    <meta name="theme-color" content="#6366f1">
    <title>Murphy's Lore 🔥 | Captain Campaign</title>
    <link rel="stylesheet" href="campaign-styles.css">
</head>
<body>
    <!-- Animated Background -->
    <div class="bg-animation">
        <div class="gradient-orb orb-1"></div>
        <div class="gradient-orb orb-2"></div>
        <div class="gradient-orb orb-3"></div>
    </div>

    <!-- Main Container -->
    <div class="container">
        <!-- Hero Section (Original Slick Landing) -->
        <header class="hero">
            <div class="logo-container">
                <div class="logo-glow"></div>
                <h1 class="glitch" data-text="MURPHY'S">MURPHY'S</h1>
                <h2 class="neon-text">LORE</h2>
            </div>
            <p class="tagline">Where Legends Begin 🚀</p>
            <div class="pulse-ring"></div>
        </header>

        <!-- Feature Cards -->
        <section class="features">
            <div class="card glass-card">
                <div class="card-icon">📱</div>
                <h3>Mobile Optimized</h3>
                <p>Slick experience on any device</p>
            </div>

            <div class="card glass-card">
                <div class="card-icon">⚡</div>
                <h3>Lightning Fast</h3>
                <p>Built for speed & style</p>
            </div>

            <div class="card glass-card">
                <div class="card-icon">🎨</div>
                <h3>Next Level Design</h3>
                <p>Dripping in swag</p>
            </div>
        </section>

        <!-- QR Code Section -->
        <section class="qr-section">
            <h2 class="section-title">Get the Code 📲</h2>
            <div class="qr-container glass-card">
                <div id="qrcode"></div>
                <p class="qr-label">Scan to access the repo</p>
                <a href="https://github.com/Blackcockatoo/murphys-lore-" class="github-link" target="_blank">
                    <svg class="github-icon" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
                    </svg>
                    View on GitHub
                </a>
            </div>
        </section>

        <!-- Download Section -->
        <section class="download-section">
            <h2 class="section-title">Level Up 🎯</h2>
            <div class="download-grid">
                <button class="download-btn primary-btn" onclick="window.open('https://github.com/Blackcockatoo/murphys-lore-/archive/refs/heads/main.zip', '_blank')">
                    <span class="btn-icon">⬇️</span>
                    <span class="btn-text">Download ZIP</span>
                    <span class="btn-shimmer"></span>
                </button>

                <button class="download-btn secondary-btn" onclick="copyToClipboard('git clone https://github.com/Blackcockatoo/murphys-lore-.git')">
                    <span class="btn-icon">📋</span>
                    <span class="btn-text">Copy Git Clone</span>
                    <span class="btn-shimmer"></span>
                </button>
            </div>
            <div id="copyNotification" class="copy-notification">Copied to clipboard! 🔥</div>
        </section>

        <!-- Stats Section -->
        <section class="stats-section">
            <div class="stat glass-card">
                <div class="stat-value" data-target="100">0</div>
                <div class="stat-label">% Swag</div>
            </div>
            <div class="stat glass-card">
                <div class="stat-value" data-target="2025">0</div>
                <div class="stat-label">Level</div>
            </div>
            <div class="stat glass-card">
                <div class="stat-value" data-target="999">0</div>
                <div class="stat-label">Vibes</div>
            </div>
        </section>

        <!-- CAMPAIGN/GAME CONTENT START (from murphys-lore-final-updated.html) -->
        
        <!-- The original hero section from the second HTML is removed to avoid duplication. -->
        
        <!-- Mandala Drawing Section -->
        <div class="mandala-section">
            <!-- Crest watermark -->
            <div class="crest-watermark" style="top: 5%; right: 5%;">
                <svg viewBox="0 0 300 350" xmlns="http://www.w3.org/2000/svg">
                    <path d="M 150 20 C 180 20, 220 30, 250 50 L 250 180 C 250 240, 220 290, 150 330 C 80 290, 50 240, 50 180 L 50 50 C 80 30, 120 20, 150 20 Z" fill="#0a0e27" stroke="#FFD700" stroke-width="4"/>
                    <path d="M 90 130 L 90 210 M 90 130 L 150 180 M 150 180 L 210 130 L 210 210" stroke="#FFD700" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                </svg>
            </div>

            <div class="mandala-container">
                <h2 class="mandala-title">Draw Your Vision</h2>
                <p class="mandala-subtitle">Your mark. Our movement. Leave a piece of the story.</p>
                <div class="canvas-wrapper">
                    <canvas id="mandalaCanvas" width="600" height="600"></canvas>
                </div>
                <div class="canvas-controls">
                    <button class="canvas-btn" onclick="clearCanvas()">Clear Canvas</button>
                    <button class="canvas-btn" onclick="changeColor()">Change Color</button>
                </div>
                <div class="bss-tag" id="bssTag">
                    Designed with <a href="javascript:void(0)" class="bss-link">Blue Snake Studios</a> vibes 🐍✨
                </div>
            </div>
        </div>

        <!-- Law vs Lore Section -->
        <section class="comparison">
            <!-- Crest watermark -->
            <div class="crest-watermark" style="bottom: 10%; left: 5%;">
                <svg viewBox="0 0 300 350" xmlns="http://www.w3.org/2000/svg">
                    <path d="M 150 20 C 180 20, 220 30, 250 50 L 250 180 C 250 240, 220 290, 150 330 C 80 290, 50 240, 50 180 L 50 50 C 80 30, 120 20, 150 20 Z" fill="#0a0e27" stroke="#FFD700" stroke-width="4"/>
                    <path d="M 90 130 L 90 210 M 90 130 L 150 180 M 150 180 L 210 130 L 210 210" stroke="#FFD700" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                </svg>
            </div>

            <div class="container">
                <h2 class="section-title">MURPHY'S LAW vs. MURPHY'S LORE</h2>
                <div class="comparison-grid">
                    <div class="comparison-card law-card">
                        <h3 class="card-title">MURPHY'S LAW</h3>
                        <div class="comparison-item">Bad luck happens.</div>
                        <div class="comparison-item">You can't stop it.</div>
                        <div class="truth">The Truth: Bad luck happens.</div>
                    </div>
                    <div class="comparison-card lore-card">
                        <h3 class="card-title">MURPHY'S LORE</h3>
                        <div class="comparison-item">It's what you do when things go wrong.</div>
                        <div class="comparison-item">It's how legends are made.</div>
                        <div class="truth">The Truth: We choose what happens next.</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- The Code Section -->
        <section class="code">
            <!-- Crest watermark -->
            <div class="crest-watermark" style="top: 15%; right: 8%;">
                <svg viewBox="0 0 300 350" xmlns="http://www.w3.org/2000/svg">
                    <path d="M 150 20 C 180 20, 220 30, 250 50 L 250 180 C 250 240, 220 290, 150 330 C 80 290, 50 240, 50 180 L 50 50 C 80 30, 120 20, 150 20 Z" fill="#0a0e27" stroke="#FFD700" stroke-width="4"/>
                    <path d="M 90 130 L 90 210 M 90 130 L 150 180 M 150 180 L 210 130 L 210 210" stroke="#FFD700" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                </svg>
            </div>

            <div class="container">
                <h2 class="section-title">THE CODE: 7 Rules for a Better School</h2>
                <div class="code-grid">
                    <div class="rule">
                        <div class="rule-number">01</div>
                        <h3 class="rule-title">Own Your Story</h3>
                        <p class="rule-text">Take responsibility for your actions and your words. No excuses, just growth.</p>
                    </div>
                    <div class="rule">
                        <div class="rule-number">02</div>
                        <h3 class="rule-title">Lift Others Up</h3>
                        <p class="rule-text">A captain leads by example. Support your peers, celebrate their wins, and help them when they fall.</p>
                    </div>
                    <div class="rule">
                        <div class="rule-number">03</div>
                        <h3 class="rule-title">Find the Lore</h3>
                        <p class="rule-text">Look for the lesson in every setback. Murphy's Law is a challenge, not a destiny.</p>
                    </div>
                    <div class="rule">
                        <div class="rule-number">04</div>
                        <h3 class="rule-title">Stay 100%</h3>
                        <p class="rule-text">Be authentic. Your true self is your best self. Don't let the pressure change who you are.</p>
                    </div>
                    <div class="rule">
                        <div class="rule-number">05</div>
                        <h3 class="rule-title">Speak Your Truth</h3>
                        <p class="rule-text">Use your voice. Be respectful, but be heard. Change starts with a conversation.</p>
                    </div>
                    <div class="rule">
                        <div class="rule-number">06</div>
                        <h3 class="rule-title">The Full Suit</h3>
                        <p class="rule-text">Commit fully. Half-measures get half-results. Whatever you do, do it with your whole heart.</p>
                    </div>
                    <div class="rule">
                        <div class="rule-number">07</div>
                        <h3 class="rule-title">Vibe Check</h3>
                        <p class="rule-text">Keep the energy positive. Your attitude is contagious. Spread the good vibes.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Promise Section -->
        <section class="promise">
            <div class="container">
                <div class="promise-content">
                    <h2 class="section-title">THE PROMISE</h2>
                    <p class="promise-intro">As your Captain, I promise to:</p>
                    <ul class="promise-list">
                        <li class="promise-item">Bring the **Full Suit** to every challenge.</li>
                        <li class="promise-item">Create a culture where **Lore** beats Law.</li>
                        <li class="promise-item">Ensure every student feels **100%** supported.</li>
                        <li class="promise-item">Lead with **Vibes** and not just rules.</li>
                    </ul>
                    <p class="promise-closing">Let's make this year legendary. Vote Murphy's Lore.</p>
                </div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="cta">
            <div class="container">
                <h2 class="cta-main">READY TO VOTE?</h2>
                <p class="cta-sub">Join the movement. Play the game. Leave your mark.</p>
                <a href="#gameModal" class="vote-button" id="voteBtn">
                    VOTE MURPHY'S LORE
                </a>
                <p class="tagline">The Future is Lore.</p>
            </div>
        </section>
        
        <!-- CAMPAIGN/GAME CONTENT END -->

        <!-- Footer (Original Footer is kept) -->
        <footer class="footer">
            <p>Built with 💎 for Murphy</p>
            <p class="footer-subtext">Campaign 2025 | No Cap</p>
        </footer>
    </div>

    <!-- Murphy's Lore Arcade Modal (PAC-FROG) -->
    <div class="murphy-modal" id="gameModal" role="dialog" aria-modal="true" aria-hidden="true">
        <div class="murphy-modal-card">
            <button class="murphy-modal-close" id="gameClose" aria-label="Close Game Modal">×</button>
            <h3 class="murphy-modal-title">MURPHY'S LORE ARCADE</h3>
            <p class="murphy-modal-text">Play the legendary **MURPHY'S LEAP** game! A small token of the fun and commitment I bring to the role.</p>
            <div class="murphy-iframe-wrap">
                <iframe id="gameFrame" title="Murphy's Leap Game" sandbox="allow-scripts allow-same-origin"></iframe>
            </div>
            <div class="murphy-modal-actions">
                <button class="canvas-btn" id="playGameBtn">Play MURPHY'S LEAP</button>
                <a class="canvas-btn" id="downloadGameBtn" download="murphys-leap.html" href="javascript:void(0)">Download Game HTML</a>
                <button class="canvas-btn" id="closeGameBtn">Close</button>
            </div>
            <p class="murphy-modal-foot">Game is fully embedded in the page for offline play!</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="qrcode.min.js"></script>
    <script src="campaign-script.js"></script>
</body>
</html>
"""
    with open(NEW_HTML_FILE, 'w') as f:
        f.write(final_html.strip())
    print(f"HTML consolidated to {NEW_HTML_FILE}")

# --- 4. Execute Consolidation ---
# I cannot execute the script directly because I don't have the full GAME_B64 string.
# I will perform the consolidation manually by writing the final files.

# --- Manual Consolidation of CSS ---
# I will combine the two CSS files and write to campaign-styles.css
css_content_1 = """
/* Reset & Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --primary: #6366f1;
    --secondary: #ec4899;
    --accent: #14b8a6;
    --dark: #0f0f23;
    --darker: #050510;
    --light: #ffffff;
    --glass: rgba(255, 255, 255, 0.1);
    --glow: rgba(99, 102, 241, 0.5);
}

body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: var(--darker);
    color: var(--light);
    overflow-x: hidden;
    min-height: 100vh;
    position: relative;
}

/* Animated Background */
.bg-animation {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    overflow: hidden;
    background: linear-gradient(135deg, #0f0f23 0%, #1a0b2e 50%, #16213e 100%);
}

.gradient-orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.6;
    animation: float 20s ease-in-out infinite;
}

.orb-1 {
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, var(--primary) 0%, transparent 70%);
    top: -10%;
    left: -10%;
    animation-delay: 0s;
}

.orb-2 {
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, var(--secondary) 0%, transparent 70%);
    bottom: -20%;
    right: -10%;
    animation-delay: 7s;
}

.orb-3 {
    width: 350px;
    height: 350px;
    background: radial-gradient(circle, var(--accent) 0%, transparent 70%);
    top: 40%;
    right: 10%;
    animation-delay: 14s;
}

@keyframes float {
    0%, 100% { transform: translate(0, 0) rotate(0deg); }
    33% { transform: translate(50px, -50px) rotate(120deg); }
    66% { transform: translate(-30px, 30px) rotate(240deg); }
}

/* Container */
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem 1rem;
    position: relative;
    z-index: 1;
}

/* Hero Section */
.hero {
    text-align: center;
    padding: 4rem 1rem;
    position: relative;
    margin-bottom: 4rem;
}

.logo-container {
    position: relative;
    display: inline-block;
}

.logo-glow {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, var(--glow) 0%, transparent 70%);
    animation: pulse 3s ease-in-out infinite;
    z-index: -1;
}

@keyframes pulse {
    0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
    50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.8; }
}

/* Glitch Effect */
.glitch {
    font-size: clamp(3rem, 10vw, 6rem);
    font-weight: 900;
    text-transform: uppercase;
    position: relative;
    letter-spacing: 0.1em;
    background: linear-gradient(90deg, var(--primary), var(--secondary), var(--accent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.5rem;
    animation: glitch-animation 5s infinite;
}

@keyframes glitch-animation {
    0%, 90%, 100% { transform: translate(0); }
    92% { transform: translate(-2px, 2px); }
    94% { transform: translate(2px, -2px); }
    96% { transform: translate(-2px, -2px); }
    98% { transform: translate(2px, 2px); }
}

.neon-text {
    font-size: clamp(2rem, 8vw, 4rem);
    font-weight: 800;
    text-transform: uppercase;
    color: var(--light);
    text-shadow:
        0 0 10px var(--primary),
        0 0 20px var(--primary),
        0 0 30px var(--primary),
        0 0 40px var(--secondary);
    animation: neon-flicker 3s ease-in-out infinite;
    letter-spacing: 0.2em;
}

@keyframes neon-flicker {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
    55% { opacity: 1; }
    57% { opacity: 0.9; }
}

.tagline {
    font-size: clamp(1rem, 3vw, 1.5rem);
    margin-top: 1.5rem;
    color: var(--accent);
    font-weight: 600;
    letter-spacing: 0.1em;
    animation: fadeInUp 1s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.pulse-ring {
    position: absolute;
    bottom: -20px;
    left: 50%;
    transform: translateX(-50%);
    width: 100px;
    height: 100px;
    border: 3px solid var(--primary);
    border-radius: 50%;
    animation: pulse-ring 2s ease-out infinite;
}

@keyframes pulse-ring {
    0% {
        opacity: 1;
        transform: translateX(-50%) scale(0.5);
    }
    100% {
        opacity: 0;
        transform: translateX(-50%) scale(1.5);
    }
}

/* Glass Card Effect */
.glass-card {
    background: var(--glass);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    padding: 2rem;
    transition: all 0.3s ease;
    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
}

.glass-card:hover {
    transform: translateY(-5px);
    border-color: var(--primary);
    box-shadow: 0 12px 48px 0 rgba(99, 102, 241, 0.3);
}

/* Features Section */
.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-bottom: 4rem;
    animation: fadeInUp 1s ease-out 0.3s both;
}

.card {
    text-align: center;
}

.card-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
    animation: bounce 2s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.card h3 {
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
    background: linear-gradient(90deg, var(--primary), var(--accent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.card p {
    color: rgba(255, 255, 255, 0.7);
    font-size: 1rem;
}

/* Section Title */
.section-title {
    text-align: center;
    font-size: clamp(2rem, 5vw, 3rem);
    margin-bottom: 2rem;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 800;
}

/* QR Section */
.qr-section {
    margin-bottom: 4rem;
    animation: fadeInUp 1s ease-out 0.6s both;
}

.qr-container {
    max-width: 400px;
    margin: 0 auto;
    text-align: center;
}

#qrcode {
    display: inline-block;
    padding: 1rem;
    background: white;
    border-radius: 15px;
    margin-bottom: 1rem;
}

#qrcode img {
    display: block !important;
    margin: 0 auto !important;
}

.qr-label {
    color: rgba(255, 255, 255, 0.8);
    font-size: 1rem;
    margin-bottom: 1.5rem;
}

.github-link {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 1rem 2rem;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
}

.github-link:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(99, 102, 241, 0.6);
}

.github-icon {
    width: 24px;
    height: 24px;
}

/* Download Section */
.download-section {
    margin-bottom: 4rem;
    animation: fadeInUp 1s ease-out 0.9s both;
}

.download-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    max-width: 800px;
    margin: 0 auto;
}

.download-btn {
    position: relative;
    padding: 1.5rem 2rem;
    border: none;
    border-radius: 15px;
    font-size: 1.1rem;
    font-weight: 700;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.primary-btn {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    box-shadow: 0 8px 30px rgba(99, 102, 241, 0.4);
}

.primary-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 40px rgba(99, 102, 241, 0.6);
}

.secondary-btn {
    background: linear-gradient(135deg, var(--accent), #10b981);
    color: white;
    box-shadow: 0 8px 30px rgba(20, 184, 166, 0.4);
}

.secondary-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 40px rgba(20, 184, 166, 0.6);
}

.btn-icon {
    font-size: 1.5rem;
}

.btn-shimmer {
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s;
}

.download-btn:hover .btn-shimmer {
    left: 100%;
}

.copy-notification {
    position: fixed;
    bottom: 2rem;
    left: 50%;
    transform: translateX(-50%) translateY(100px);
    background: linear-gradient(135deg, var(--accent), #10b981);
    color: white;
    padding: 1rem 2rem;
    border-radius: 50px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.3s ease;
    z-index: 1000;
    box-shadow: 0 8px 30px rgba(20, 184, 166, 0.6);
}

.copy-notification.show {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
}

/* Stats Section */
.stats-section {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 2rem;
    margin-bottom: 4rem;
    animation: fadeInUp 1s ease-out 1.2s both;
}

.stat {
    text-align: center;
}

.stat-value {
    font-size: clamp(3rem, 8vw, 5rem);
    font-weight: 900;
    background: linear-gradient(135deg, var(--primary), var(--accent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
    margin-bottom: 0.5rem;
}

.stat-label {
    font-size: 1.2rem;
    color: rgba(255, 255, 255, 0.7);
    text-transform: uppercase;
    letter-spacing: 0.1em;
}

/* Footer */
.footer {
    text-align: center;
    padding: 3rem 1rem;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    margin-top: 4rem;
}

.footer p {
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
}

.footer-subtext {
    color: rgba(255, 255, 255, 0.5);
    font-size: 1rem;
}

/* Mobile Optimizations */
@media (max-width: 768px) {
    .container {
        padding: 1rem 0.5rem;
    }

    .hero {
        padding: 2rem 1rem;
    }

    .features {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }

    .download-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
        padding: 0 1rem;
    }

    .stats-section {
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
    }

    .glass-card {
        padding: 1.5rem;
    }

    .orb-1, .orb-2, .orb-3 {
        filter: blur(40px);
    }
}

@media (max-width: 480px) {
    .glitch {
        letter-spacing: 0.05em;
    }

    .neon-text {
        letter-spacing: 0.1em;
    }

    .download-btn {
        padding: 1.2rem 1.5rem;
        font-size: 1rem;
    }

    .stats-section {
        gap: 0.5rem;
    }

    .stat-value {
        font-size: 2.5rem;
    }

    .stat-label {
        font-size: 0.9rem;
    }
}

/* Loading Animation */
@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Selection Style */
::selection {
    background: var(--primary);
    color: white;
}

::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: var(--darker);
}

::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, var(--primary), var(--secondary));
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(180deg, var(--secondary), var(--accent));
}

/* --- murphys-lore-final-updated.html (Campaign/Game Styles) --- */

/* Base Overrides for Campaign Sections */
body {
    /* Re-apply campaign body styles */
    font-family: 'Arial Black', 'Arial Bold', Gadget, sans-serif;
    background: #0a0e27; /* Darker campaign background */
    color: #FFD700; /* Gold text color */
    line-height: 1.6;
}

.container {
    /* Adjust padding for campaign sections */
    padding: 20px;
}

/* Hero Section (Campaign) - Styles kept for the Mandala/Law vs Lore sections */
.hero {
    /* The original hero section is kept for the landing page, but these styles are for the sections below */
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 40px 20px;
    position: relative;
    overflow: hidden;
    background: linear-gradient(135deg, #0a0e27 0%, #1a1f4d 50%, #0a0e27 100%);
}

/* Hepta-symmetry pattern + Murphy's glyphs floating */
.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        radial-gradient(circle at 50% 50%, transparent 30%, rgba(255, 215, 0, 0.03) 31%, transparent 32%),
        conic-gradient(from 0deg at 50% 50%, 
            transparent 0deg, 
            rgba(255, 215, 0, 0.05) 51.43deg,
            transparent 51.43deg 102.86deg,
            rgba(255, 215, 0, 0.05) 102.86deg 154.29deg,
            transparent 154.29deg 205.71deg,
            rgba(255, 215, 0, 0.05) 205.71deg 257.14deg,
            transparent 257.14deg 308.57deg,
            rgba(255, 215, 0, 0.05) 308.57deg 360deg);
    animation: rotate-hepta 42s linear infinite;
}

@keyframes rotate-hepta {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* Floating Murphy glyphs in background */
.floating-glyph {
    position: absolute;
    opacity: 0.08;
    pointer-events: none;
}

.floating-glyph svg {
    width: 100px;
    height: 100px;
}

@keyframes float-glyph {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    50% { transform: translateY(-20px) rotate(5deg); }
}

/* Crest watermark */
.crest-watermark {
    position: absolute;
    opacity: 0.05;
    pointer-events: none;
    z-index: 0;
}

.crest-watermark svg {
    width: 300px;
    height: 350px;
}

.hero-content {
    position: relative;
    z-index: 1;
}

h1 {
    font-size: clamp(2.5rem, 8vw, 5rem);
    color: #FFD700;
    text-shadow: 
        0 0 20px rgba(255, 215, 0, 0.5),
        0 0 40px rgba(255, 215, 0, 0.3),
        3px 3px 6px rgba(0,0,0,0.8);
    margin-bottom: 20px;
    letter-spacing: 2px;
}

.subtitle {
    font-size: clamp(1.2rem, 3vw, 1.8rem);
    color: #9db4ff;
    margin-bottom: 30px;
    font-weight: normal;
}

.hero-text {
    font-size: clamp(1rem, 2.5vw, 1.3rem);
    max-width: 700px;
    margin: 0 auto 30px;
    line-height: 1.8;
    font-weight: normal;
    font-family: Arial, sans-serif;
    color: #e0e7ff;
}

.highlight {
    color: #FFD700;
    font-weight: bold;
    font-size: 1.2em;
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
}

/* Mandala Drawing Canvas Section */
.mandala-section {
    background: linear-gradient(135deg, #0a0e27 0%, #1a1f4d 100%);
    padding: 60px 20px;
    position: relative;
}

.mandala-container {
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
    position: relative;
}

.mandala-title {
    font-size: clamp(1.5rem, 4vw, 2.5rem);
    color: #FFD700;
    margin-bottom: 20px;
    text-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
}

.mandala-subtitle {
    font-size: 1.1rem;
    color: #9db4ff;
    margin-bottom: 30px;
    font-weight: normal;
    font-family: Arial, sans-serif;
}

.canvas-wrapper {
    background: #0a0e27;
    border: 3px solid #FFD700;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 
        0 0 30px rgba(255, 215, 0, 0.3),
        inset 0 0 20px rgba(255, 215, 0, 0.1);
    margin-bottom: 20px;
    position: relative;
}

#mandalaCanvas {
    display: block;
    margin: 0 auto;
    background: #000814;
    border-radius: 10px;
    cursor: crosshair;
    touch-action: none;
}

.canvas-controls {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}

.canvas-btn {
    background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
    color: #0a0e27;
    border: none;
    padding: 15px 30px;
    font-size: 1.1rem;
    font-weight: bold;
    border-radius: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 5px 15px rgba(255, 215, 0, 0.3);
}

.canvas-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(255, 215, 0, 0.5);
}

.canvas-btn:active {
    transform: translateY(0);
}

.bss-tag {
    font-size: 0.9rem;
    color: #9db4ff;
    margin-top: 15px;
    font-family: Arial, sans-serif;
    font-weight: normal;
    opacity: 0;
    transition: opacity 0.5s ease;
}

.bss-tag.show {
    opacity: 1;
}

.bss-link {
    color: #FFD700;
    text-decoration: none;
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
}

.bss-link:hover {
    text-shadow: 0 0 15px rgba(255, 215, 0, 0.6);
}

.scroll-indicator {
    margin-top: 40px;
    animation: bounce 2s infinite;
    cursor: pointer;
    font-size: 2rem;
    color: #FFD700;
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
    40% { transform: translateY(-20px); }
    60% { transform: translateY(-10px); }
}

/* Section Styles */
section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    padding: 60px 20px;
    position: relative;
}

.section-title {
    font-size: clamp(2rem, 5vw, 3.5rem);
    color: #FFD700;
    margin-bottom: 40px;
    text-align: center;
    text-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
    position: relative;
    z-index: 1;
}

/* Law vs Lore Section */
.comparison {
    background: linear-gradient(135deg, #0a0e27 0%, #1a1f4d 100%);
}

.comparison-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 40px;
    max-width: 1000px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.comparison-card {
    background: rgba(255, 215, 0, 0.05);
    border-radius: 20px;
    padding: 40px;
    border: 2px solid;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
    overflow: hidden;
}

.comparison-card::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 150px;
    height: 150px;
    background-image: url('data:image/svg+xml,<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><g stroke="%23FFD700" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M 30 150 L 30 50 L 100 110 L 170 50 L 170 150"/><path d="M 75 45 L 125 45 L 100 90" stroke-width="8"/></g><circle cx="100" cy="160" r="6" fill="%23FFD700"/></svg>');
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    opacity: 0.03;
    pointer-events: none;
}

.comparison-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(255, 215, 0, 0.2);
}

.law-card {
    border-color: #ff4444;
}

.lore-card {
    border-color: #FFD700;
}

.card-title {
    font-size: 2rem;
    margin-bottom: 30px;
    text-align: center;
}

.law-card .card-title {
    color: #ff4444;
}

.lore-card .card-title {
    color: #FFD700;
}

.comparison-item {
    font-size: 1.1rem;
    margin-bottom: 20px;
    font-family: Arial, sans-serif;
    font-weight: normal;
    color: #e0e7ff;
}

.truth {
    margin-top: 30px;
    padding-top: 30px;
    border-top: 2px solid rgba(255,255,255,0.2);
    font-weight: bold;
    font-size: 1.2rem;
    color: #FFD700;
}

/* The Code Section */
.code {
    background: linear-gradient(135deg, #1a1f4d 0%, #0a0e27 100%);
}

.code-grid {
    display: grid;
    gap: 30px;
    max-width: 900px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.rule {
    background: rgba(255, 215, 0, 0.1);
    border-left: 5px solid #FFD700;
    padding: 30px;
    border-radius: 10px;
    transition: all 0.3s ease;
    cursor: pointer;
    box-shadow: 0 0 15px rgba(255, 215, 0, 0.1);
    position: relative;
    overflow: hidden;
}

.rule::after {
    content: '';
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    width: 60px;
    height: 60px;
    background-image: url('data:image/svg+xml,<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><g stroke="%23FFD700" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M 30 150 L 30 50 L 100 110 L 170 50 L 170 150"/><path d="M 75 45 L 125 45 L 100 90" stroke-width="8"/></g><circle cx="100" cy="160" r="6" fill="%23FFD700"/></svg>');
    background-size: contain;
    background-repeat: no-repeat;
    opacity: 0.1;
    pointer-events: none;
}

.rule:hover {
    background: rgba(255, 215, 0, 0.2);
    transform: translateX(10px);
    box-shadow: 0 0 25px rgba(255, 215, 0, 0.3);
}

.rule:hover::after {
    opacity: 0.2;
}

.rule-number {
    color: #FFD700;
    font-size: 1.5rem;
    margin-bottom: 10px;
}

.rule-title {
    font-size: 1.5rem;
    color: #FFD700;
    margin-bottom: 10px;
}

.rule-text {
    font-size: 1.1rem;
    font-family: Arial, sans-serif;
    font-weight: normal;
    line-height: 1.6;
    color: #e0e7ff;
}

/* Promise Section */
.promise {
    background: linear-gradient(135deg, #0a0e27 0%, #1a1f4d 100%);
}

.promise-content {
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
    position: relative;
    z-index: 1;
}

.promise-intro {
    font-size: 1.5rem;
    margin-bottom: 40px;
    color: #FFD700;
}

.promise-list {
    text-align: left;
    display: inline-block;
    margin: 40px 0;
}

.promise-item {
    font-size: 1.2rem;
    margin: 20px 0;
    padding-left: 30px;
    position: relative;
    font-family: Arial, sans-serif;
    font-weight: normal;
    color: #e0e7ff;
}

.promise-item::before {
    content: '✓';
    position: absolute;
    left: 0;
    color: #FFD700;
    font-size: 1.5rem;
    font-weight: bold;
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
}

.promise-closing {
    font-size: 1.5rem;
    margin-top: 40px;
    color: #FFD700;
    font-weight: bold;
}

/* CTA Section */
.cta {
    background: linear-gradient(135deg, #1a1f4d 0%, #0a0e27 100%);
    text-align: center;
    position: relative;
}

.cta-main {
    font-size: clamp(3rem, 7vw, 5rem);
    color: #FFD700;
    margin-bottom: 30px;
    text-shadow: 
        0 0 30px rgba(255, 215, 0, 0.5),
        3px 3px 6px rgba(0,0,0,0.8);
    position: relative;
    z-index: 1;
}

.cta-sub {
    font-size: clamp(1.5rem, 4vw, 2.5rem);
    margin-bottom: 40px;
    color: #9db4ff;
}

.vote-button {
    display: inline-block;
    background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
    color: #0a0e27;
    padding: 25px 60px;
    font-size: 1.8rem;
    border-radius: 50px;
    text-decoration: none;
    font-weight: bold;
    transition: all 0.3s ease;
    box-shadow: 0 10px 30px rgba(255, 215, 0, 0.3);
    margin-bottom: 40px;
    position: relative;
    z-index: 1;
}

.vote-button:hover {
    transform: scale(1.1);
    box-shadow: 0 15px 40px rgba(255, 215, 0, 0.5);
}

.tagline {
    font-size: 2rem;
    color: #FFD700;
    margin-top: 40px;
    font-weight: bold;
}

/* Responsive */
@media (max-width: 768px) {
    .comparison-grid {
        grid-template-columns: 1fr;
    }
    
    .rule {
        padding: 20px;
    }

    #mandalaCanvas {
        width: 100% !important;
        height: auto !important;
    }

    .floating-glyph svg,
    .crest-watermark svg {
        width: 60px;
        height: 70px;
    }
}

/* --- Murphy's Lore Arcade Modal (PAC-FROG) --- */
.murphy-modal{
    position: fixed;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(0,0,0,0.72);
    z-index: 99999;
}
.murphy-modal.show{ display: flex; }

.murphy-modal-card{
    width: min(96vw, 1040px);
    background: rgba(10,14,39,0.92);
    border: 2px solid #FFD700;
    border-radius: 20px;
    padding: 18px 18px 16px;
    box-shadow:
        0 30px 90px rgba(0,0,0,0.65),
        0 0 40px rgba(255, 215, 0, 0.18);
    position: relative;
    backdrop-filter: blur(10px);
}

.murphy-modal-close{
    position: absolute;
    top: 12px;
    right: 12px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: 2px solid rgba(255,215,0,0.35);
    background: rgba(255,215,0,0.08);
    color: #FFD700;
    font-size: 26px;
    font-weight: bold;
    cursor: pointer;
    line-height: 1;
    text-shadow: 0 0 10px rgba(255,215,0,0.25);
}
.murphy-modal-close:hover{
    box-shadow: 0 0 22px rgba(255,215,0,0.22);
    transform: translateY(-1px);
}

.murphy-modal-title{
    margin: 2px 0 8px;
    font-size: clamp(1.4rem, 3vw, 2rem);
    color: #FFD700;
    text-shadow: 0 0 16px rgba(255, 215, 0, 0.35);
}

.murphy-modal-text, .murphy-modal-foot{
    font-family: Arial, sans-serif;
    font-weight: normal;
    color: #e0e7ff;
    margin: 0 0 10px;
    line-height: 1.6;
}

.murphy-modal-actions{
    display: flex;
    gap: 14px;
    flex-wrap: wrap;
    justify-content: center;
    margin: 10px 0 8px;
}

.murphy-iframe-wrap{
    margin-top: 14px;
    border-radius: 16px;
    overflow: hidden;
    border: 2px solid rgba(255,215,0,0.35);
    background: #000814;
    height: min(70vh, 720px);
    box-shadow: inset 0 0 20px rgba(255,215,0,0.08);
}

.murphy-iframe-wrap iframe{
    width: 100%;
    height: 100%;
    border: 0;
    background: #000814;
}
"""
# Write the consolidated CSS
# I will use the file tool to write the consolidated CSS.
# I will then write the consolidated JS.
# Finally, I will write the consolidated HTML.<ctrl95><ctrl42>call:default_api:file{action:
