// --- script.js (Original Landing Page Scripts) ---

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initQRCode();
    initCounters();
    initParallax();
    initSmoothScroll();
    
    // Initialize the game modal logic after DOM is ready
    initGameModal();
    
    // Initialize the Mandala canvas
    initCanvas();
});

// Generate QR Code
function initQRCode() {
    // The QR code will point to the final deployed URL. For now, it points to the repo.
    const qrcode = new QRCode(document.getElementById("qrcode"), {
        text: "https://github.com/Blackcockatoo/murphys-lore-",
        width: 200,
        height: 200,
        colorDark: "#6366f1",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });
}

// Animated Counter
function initCounters() {
    const counters = document.querySelectorAll('.stat-value');
    const speed = 200; // Animation speed

    const animateCounter = (counter) => {
        const target = +counter.getAttribute('data-target');
        const increment = target / speed;
        let count = 0;

        const updateCount = () => {
            count += increment;
            if (count < target) {
                counter.textContent = Math.ceil(count);
                requestAnimationFrame(updateCount);
            } else {
                counter.textContent = target;
            }
        };

        updateCount();
    };

    // Intersection Observer for triggering animation when in view
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(counter => {
        observer.observe(counter);
    });
}

// Copy to Clipboard Function
function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification();
        }).catch(err => {
            fallbackCopyToClipboard(text);
        });
    } else {
        fallbackCopyToClipboard(text);
    }
}

// Fallback for older browsers
function fallbackCopyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
        document.execCommand('copy');
        showNotification();
    } catch (err) {
        console.error('Failed to copy text: ', err);
    }

    document.body.removeChild(textArea);
}

// Show Copy Notification
function showNotification() {
    const notification = document.getElementById('copyNotification');
    notification.classList.add('show');

    setTimeout(() => {
        notification.classList.remove('show');
    }, 2000);
}

// Parallax Effect on Mouse Move
function initParallax() {
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });

    const updateParallax = () => {
        targetX += (mouseX - targetX) * 0.05;
        targetY += (mouseY - targetY) * 0.05;

        const cards = document.querySelectorAll('.glass-card');
        cards.forEach((card, index) => {
            const depth = (index + 1) * 0.02;
            const moveX = (targetX - window.innerWidth / 2) * depth;
            const moveY = (targetY - window.innerHeight / 2) * depth;
            card.style.transform = `translate(${moveX}px, ${moveY}px)`;
        });

        requestAnimationFrame(updateParallax);
    };

    // Only enable parallax on desktop
    if (window.innerWidth > 768) {
        updateParallax();
    }
}

// Smooth Scroll for Internal Links
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Add Sparkle Effect on Click
document.addEventListener('click', (e) => {
    createSparkle(e.clientX, e.clientY);
});

function createSparkle(x, y) {
    const sparkle = document.createElement('div');
    sparkle.style.position = 'fixed';
    sparkle.style.left = x + 'px';
    sparkle.style.top = y + 'px';
    sparkle.style.width = '10px';
    sparkle.style.height = '10px';
    sparkle.style.background = 'radial-gradient(circle, #6366f1, transparent)';
    sparkle.style.borderRadius = '50%';
    sparkle.style.pointerEvents = 'none';
    sparkle.style.zIndex = '9999';
    sparkle.style.animation = 'sparkle-fade 0.6s ease-out forwards';

    document.body.appendChild(sparkle);

    setTimeout(() => {
        sparkle.remove();
    }, 600);
}

// Add sparkle animation
const style = document.createElement('style');
style.textContent = `
    @keyframes sparkle-fade {
        0% {
            transform: scale(0) rotate(0deg);
            opacity: 1;
        }
        100% {
            transform: scale(3) rotate(180deg);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Add Ripple Effect to Buttons
document.querySelectorAll('.download-btn, .github-link').forEach(button => {
    button.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;

        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.background = 'rgba(255, 255, 255, 0.5)';
        ripple.style.transform = 'scale(0)';
        ripple.style.animation = 'ripple 0.6s ease-out';
        ripple.style.pointerEvents = 'none';

        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        this.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
});

// Add ripple animation
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);

// Easter Egg: Konami Code
let konamiCode = [];
const konamiPattern = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];

document.addEventListener('keydown', (e) => {
    konamiCode.push(e.key);
    konamiCode = konamiCode.slice(-10);

    if (konamiCode.join('') === konamiPattern.join('')) {
        activateEasterEgg();
    }
});

function activateEasterEgg() {
    document.body.style.animation = 'rainbow 2s linear infinite';
    const easterEggStyle = document.createElement('style');
    easterEggStyle.textContent = `
        @keyframes rainbow {
            0% { filter: hue-rotate(0deg); }
            100% { filter: hue-rotate(360deg); }
        }
    `;
    document.head.appendChild(easterEggStyle);

    setTimeout(() => {
        document.body.style.animation = '';
    }, 5000);
}

// Add Loading Animation
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease';
        document.body.style.opacity = '1';
    }, 100);
});

// Mobile Touch Effects
if ('ontouchstart' in window) {
    document.querySelectorAll('.glass-card').forEach(card => {
        card.addEventListener('touchstart', function() {
            this.style.transform = 'scale(0.98)';
        });

        card.addEventListener('touchend', function() {
            this.style.transform = 'scale(1)';
        });
    });
}

// Add PWA-like Features
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').then(function(registration) {
        console.log('Service Worker registration successful with scope: ', registration.scope);
    }).catch(function(err) {
        console.log('Service Worker registration failed: ', err);
    });
}

// Performance Monitoring
if (window.performance) {
    window.addEventListener('load', () => {
        const perfData = window.performance.timing;
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
        console.log(`🚀 Page loaded in ${pageLoadTime}ms - Murphy's Lore is FAST! 💎`);
    });
}

// Add Visibility Change Detection
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        document.title = '👋 Come back to Murphy\'s Lore!';
    } else {
        document.title = 'Murphy\'s Lore 🔥';
    }
});

console.log(`
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
   MURPHY'S LORE
   Campaign 2025
   No Cap Mode: ON
   Swag Level: MAX
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
`);


// --- murphys-lore-final-updated.html (Campaign/Game Scripts) ---

// ** WARNING: The full Base64 string for the embedded game is truncated in the context. **
// ** The user must ensure this variable contains the complete, correct Base64 string for the game to work offline. **
// ** I have used a placeholder for the variable definition. **
const GAME_B64 = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4NCjwhRE9DVFlQRSBodG1sPg0KPGh0bWwgbGFuZz0iZW4iPg0KPGhlYWQ+DQogICAgPG1ldGEgY2hhcnNldD0iVVRGLTgiPg0KICAgIDxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MS4wIj4NCiAgICA8dGl0bGU+TXVycGh5J3MgTGVhcCAtIFBBQy1GUk9HPC90aXRsZT4NCiAgICA8c3R5bGU+DQogICAgICAgIGJvZHl7bWFyZ2luOjA7YmFja2dyb3VuZDojMDAwODFhO2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7anVzdGlmeS1jb250ZW50OmNlbnRlcjtmbGV4LWRpcmVjdGlvbjpjb2x1bjtmb250LWZhbWlseTpzYW5zLXNlcmlmO2NvbG9yOiNmZmQ3MDA7aGVpZ2h0OjEwMHZoO30NCiAgICAgICAgY2FudmFze2JvcmRlcjoxcHggc29saWQgI2ZmZDcwMDt9DQogICAgICAgIC5jb250cm9sc3tkZWZhdWx0O21hcmdpbi10b3A6MjBweDt9DQogICAgICAgIC5idXR0b257YmFja2dyb3VuZDojZmZkNzAwO2NvbG9yOiMwYTBlMjc7Ym9yZGVyOm5vbmU7cGFkZGluZzoxMHB4IDIwcHg7Ym9yZGVyLXJhZGl1czoxMHB4O2N1cnNvcjpwb2ludGVyO21hcmdpbi1yaWdodDoxMHB4O30NCiAgICA8L3N0eWxlPg0KPC9oZWFkPg0KPGJvZHk+DQogICAgPGNhbnZhcyBpZD0iZ2FtZUNhbnZhcyIgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiPjwvY2FudmFzPg0KICAgIDxkaXYgY2xhc3M9ImNvbnRyb2xzIj4NCiAgICAgICAgPGJ1dHRvbiBpZD0ic3RhcnRCdXR0b24iPkZyb2cgTGVhcDwvYnV0dG9uPg0KICAgICAgICA8YnV0dG9uIGlkPSJyZXNldEJ1dHRvbiI+UmVzZXQgR2FtZTwvYnV0dG9uPg0KICAgIDwvZGl2Pg0KICAgIDxzY3JpcHQ+DQogICAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdH';

function b64ToUtf8(b64) {
    const bin = atob(b64);
    const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    return new TextDecoder('utf-8').decode(bytes);
}

const gameHtml = b64ToUtf8(GAME_B64);

// Prepare download link (so downloads only happen from this page)
function updateDownloadLink() {
    const dl = document.getElementById('downloadGameBtn');
    if (dl) {
        const blob = new Blob([gameHtml], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        dl.href = url;
    }
}

// Mandala Canvas Logic
let canvas, ctx, centerX, centerY, isDrawing = false, lastX = 0, lastY = 0;
let currentColor = '#FFD700';
const colors = ['#FFD700', '#FF4444', '#9db4ff', '#14b8a6'];
let colorIndex = 0;

function initCanvas() {
    canvas = document.getElementById('mandalaCanvas');
    if (!canvas) return;
    ctx = canvas.getContext('2d');
    
    // Set canvas size dynamically for responsiveness
    const wrapper = canvas.parentElement;
    const size = Math.min(wrapper.clientWidth, 600);
    canvas.width = size;
    canvas.height = size;
    
    centerX = canvas.width / 2;
    centerY = canvas.height / 2;
    
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 4;
    
    drawGuide();

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);
}

function drawGuide() {
    ctx.strokeStyle = 'rgba(255, 215, 0, 0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < 7; i++) {
        const angle = (Math.PI * 2 / 7) * i;
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX + Math.cos(angle) * centerX, centerY + Math.sin(angle) * centerY);
    }
    ctx.stroke();
}

function startDrawing(e) {
    e.preventDefault();
    isDrawing = true;
    [lastX, lastY] = getCoords(e);
}

function draw(e) {
    e.preventDefault();
    if (!isDrawing) return;
    
    const [x, y] = getCoords(e);
    
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = 4;
    
    for (let i = 0; i < 7; i++) {
        const angle = (Math.PI * 2 / 7) * i;
        
        // Rotate the coordinates
        const rotatedX = centerX + (x - centerX) * Math.cos(angle) - (y - centerY) * Math.sin(angle);
        const rotatedY = centerY + (x - centerX) * Math.sin(angle) + (y - centerY) * Math.cos(angle);
        
        const rotatedLastX = centerX + (lastX - centerX) * Math.cos(angle) - (lastY - centerY) * Math.sin(angle);
        const rotatedLastY = centerY + (lastX - centerX) * Math.sin(angle) + (lastY - centerY) * Math.cos(angle);
        
        ctx.beginPath();
        ctx.moveTo(rotatedLastX, rotatedLastY);
        ctx.lineTo(rotatedX, rotatedY);
        ctx.stroke();
    }
    
    [lastX, lastY] = [x, y];
}

function getCoords(e) {
    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;
    
    if (e.touches) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
    } else {
        clientX = e.clientX;
        clientY = e.clientY;
    }
    
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    return [x, y];
}

function stopDrawing(e) {
    e.preventDefault();
    isDrawing = false;
}

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawGuide();
    
    animateVotePattern();
}

function animateVotePattern() {
    const startTime = performance.now();
    const duration = 4000;
    
    const animate = (timestamp) => {
        const elapsed = timestamp - startTime;
        const t = elapsed / 1000;
        const progress = Math.min(elapsed / duration, 1);
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const morphProgress = 0.5 + 0.5 * Math.sin(t * 1.8);
        
        const burst1Opacity = (1 - morphProgress) * (progress < 0.7 ? 1 : (1 - progress) / 0.3);
        drawHeptaBurst(t, burst1Opacity);
        
        const yantraOpacity = morphProgress * (progress < 0.7 ? 1 : (1 - progress) / 0.3);
        drawYantraCircles(t, yantraOpacity);
        
        const webOpacity = Math.sin(t * 3) * 0.3 + 0.4;
        if (progress > 0.2 && progress < 0.7) {
            drawSacredWeb(t, webOpacity * (1 - morphProgress * 0.5));
        }
        
        if (progress > 0.4) {
            const textProgress = (progress - 0.4) / 0.6;
            const textOpacity = Math.min(textProgress * 1.5, 1);
            drawGlowText(textOpacity, t);
        }
        
        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            setTimeout(() => {
                const tag = document.getElementById('bssTag');
                tag.classList.add('show');
                
                setTimeout(() => {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    drawGuide();
                    tag.classList.remove('show');
                }, 3000);
            }, 800);
        }
    };
    
    requestAnimationFrame(animate);
}

function drawHeptaBurst(t, opacity) {
    for (let i = 0; i < 7; i++) {
        const angle = (Math.PI * 2 / 7) * i + t * 0.5;
        const innerR = 30;
        const outerR = 250 * (0.6 + 0.4 * Math.sin(t * 2 + i));
        
        const gradient = ctx.createLinearGradient(
            centerX + Math.cos(angle) * innerR,
            centerY + Math.sin(angle) * innerR,
            centerX + Math.cos(angle) * outerR,
            centerY + Math.sin(angle) * outerR
        );
        gradient.addColorStop(0, `rgba(255, 215, 0, ${opacity * 0.8})`);
        gradient.addColorStop(1, `rgba(255, 165, 0, ${opacity * 0.1})`);
        
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(
            centerX + Math.cos(angle) * outerR,
            centerY + Math.sin(angle) * outerR
        );
        ctx.stroke();
    }
}

function drawYantraCircles(t, opacity) {
    for (let ring = 1; ring <= 7; ring++) {
        const baseRadius = 35;
        const pulse = 1 + 0.15 * Math.sin(t * 3 - ring * 0.5);
        const radius = baseRadius * pulse * ring;
        
        ctx.strokeStyle = `rgba(255, 215, 0, ${opacity * (0.3 + 0.1 * (7 - ring))})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();
        
        for (let i = 0; i < 7; i++) {
            const angle = (Math.PI * 2 / 7) * i + t * 0.3;
            const x = centerX + radius * Math.cos(angle);
            const y = centerY + radius * Math.sin(angle);
            
            ctx.fillStyle = `rgba(255, 215, 0, ${opacity * 0.6})`;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

function drawSacredWeb(t, opacity) {
    const rings = 5;
    const pointsPerRing = 7;
    
    for (let ring = 0; ring < rings; ring++) {
        const radius = 50 + ring * 40;
        
        for (let i = 0; i < pointsPerRing; i++) {
            const angle1 = (Math.PI * 2 / pointsPerRing) * i + t * 0.4;
            const x1 = centerX + radius * Math.cos(angle1);
            const y1 = centerY + radius * Math.sin(angle1);
            
            if (ring < rings - 1) {
                const nextRing = ring + 1;
                const nextRadius = 50 + nextRing * 40;
                const goldenOffset = i * 1.618033988749895;
                const nextIndex = Math.floor(goldenOffset) % pointsPerRing;
                const angle2 = (Math.PI * 2 / pointsPerRing) * nextIndex + t * 0.4;
                const x2 = centerX + nextRadius * Math.cos(angle2);
                const y2 = centerY + nextRadius * Math.sin(angle2);
                
                const gradient = ctx.createLinearGradient(x1, y1, x2, y2);
                gradient.addColorStop(0, `rgba(255, 215, 0, ${opacity * 0.4})`);
                gradient.addColorStop(1, `rgba(138, 43, 226, ${opacity * 0.2})`);
                
                ctx.strokeStyle = gradient;
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(x1, y1);
                ctx.lineTo(x2, y2);
                ctx.stroke();
            }
        }
    }
}

function drawGlowText(opacity, t) {
    const pulse = 0.85 + 0.15 * Math.sin(t * 4);
    
    ctx.font = 'bold 48px Arial Black';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    for (let blur = 30; blur > 0; blur -= 5) {
        ctx.shadowBlur = blur;
        ctx.shadowColor = `rgba(255, 215, 0, ${opacity * pulse * 0.6})`;
        ctx.fillStyle = `rgba(255, 215, 0, ${opacity * pulse})`;
        ctx.fillText('VOTE FOR', centerX, centerY - 45);
        ctx.fillText('MURPHY', centerX, centerY + 10);
    }
    
    ctx.font = 'bold 32px Arial Black';
    for (let blur = 20; blur > 0; blur -= 4) {
        ctx.shadowBlur = blur;
        ctx.shadowColor = `rgba(255, 165, 0, ${opacity * pulse * 0.5})`;
        ctx.fillStyle = `rgba(255, 165, 0, ${opacity * pulse * 0.9})`;
        ctx.fillText('LETS GO!', centerX, centerY + 65);
    }
    
    ctx.shadowBlur = 0;
    
    ctx.fillStyle = `rgba(255, 215, 0, ${opacity})`;
    ctx.font = 'bold 48px Arial Black';
    ctx.fillText('VOTE FOR', centerX, centerY - 45);
    ctx.fillText('MURPHY', centerX, centerY + 10);
    
    ctx.fillStyle = `rgba(255, 165, 0, ${opacity})`;
    ctx.font = 'bold 32px Arial Black';
    ctx.fillText('LETS GO!', centerX, centerY + 65);
}

function changeColor() {
    colorIndex = (colorIndex + 1) % colors.length;
    currentColor = colors[colorIndex];
}

// Modal Logic
function initGameModal() {
    const voteBtn = document.getElementById('voteBtn');
    const modal = document.getElementById('gameModal');
    const closeX = document.getElementById('gameClose');
    const closeBtn = document.getElementById('closeGameBtn');
    const playBtn = document.getElementById('playGameBtn');
    const frame = document.getElementById('gameFrame');

    updateDownloadLink();

    function openModal() {
        modal.classList.add('show');
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
    }
    function closeModal() {
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }

    voteBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        openModal();
    });

    closeX?.addEventListener('click', closeModal);
    closeBtn?.addEventListener('click', closeModal);

    modal?.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('show')) closeModal();
    });

    playBtn?.addEventListener('click', () => {
        // Load the arcade into the iframe
        frame.srcdoc = gameHtml;
        playBtn.textContent = 'Reload MURPHY\'S LEAP';
    });
}

// Intersection Observer for the rules section (from the second HTML)
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, {
    threshold: 0.1
});

document.querySelectorAll('.rule').forEach(rule => {
    rule.style.opacity = '0';
    rule.style.transform = 'translateY(20px)';
    rule.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(rule);
});
